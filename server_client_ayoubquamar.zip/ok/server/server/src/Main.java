/*
 * TP JAVA RIP Min Serveur FTP
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Main extends Thread {

  private Socket socket;

  private String name;

  private String userPath;

  public boolean userOk;

  public boolean pwOk;

  public static void main(String[] args) {
    System.out.println("Le Serveur FTP");
    ServerSocket serveurFTP = null;

    // Cr�ation du serveur
    try {
      serveurFTP = new ServerSocket(2121);
    } catch (IOException e) {
      e.printStackTrace();
    }

    boolean fermerServeur = false;
    Socket socket;
    while (!fermerServeur) {
      // Attente d'un nouveau client
      try {
        socket = serveurFTP.accept();

        Main m = new Main(socket);
        m.start();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }

    // Fermeture du serveur
    try {
      serveurFTP.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public Main(Socket s) {
    this.socket = s;
  }

  public String getClientName() {
    return this.name;
  }

  public void setClientName(String theName) {
    this.name = theName;
  }

  public String getUserPath() {
    return this.userPath;
  }

  public void setUserPath(String theUserPath) {
    this.userPath = theUserPath;
  }

  @Override
  public void run() {
    try {
      System.out.println("Un nouveau client s'est connecte !");

      BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
      PrintStream ps = new PrintStream(socket.getOutputStream());

      ps.println("1 Bienvenue ! ");
      ps.println("1 Serveur FTP Personnel.");
      ps.println("0 Authentification : ");

      // Attente de reception de commandes et leur execution
      String commande = "";
      while (!(commande = br.readLine()).equals("bye")) {
        System.out.println(">> " + commande);
        CommandExecutor.executeCommande(ps, commande, this);
      }

      // Affichage du d�part du client
      System.out.println("Le client " + (name != null ? name + " " : "") + "s'est deconnecte !");

      // Fermeture de la socket et r�initialisation des param�tres de connexion
      socket.close();
      this.userOk = false;
      this.pwOk = false;
    } catch (IOException e) {
      // D�part subit du client
      System.out.println("Le client " + (name != null ? name + " " : "") + "s'est deconnecte !");

      // Fermeture de la socket et r�initialisation des param�tres de connexion
      try {
        socket.close();
        this.userOk = false;
        this.pwOk = false;
      } catch (IOException e1) {
        e1.printStackTrace();
      }
    }
  }
}