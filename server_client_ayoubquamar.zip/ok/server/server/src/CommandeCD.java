import java.io.PrintStream;
import java.io.File;
public class CommandeCD extends Commande {
	private Main monMain ; 
	public CommandeCD(PrintStream ps, String commandeStr) {
		super(ps, commandeStr);
		//this.monMain= m ; 
	}

	public void execute() {
		//File f1  = ps.println("La commande cd n'est pas encoré implémentée");
		 String destination = null  ;
		if(this.commandeArgs != null )
		 destination= this.commandeArgs[0];
		destination = "/"+ destination ;
		
		//string pathmain = this.monMain.getAbsolutePath();
		
	}

}
