import java.io.PrintStream;
import java.net.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
public class CommandeGET extends Commande {
	public byte []b = new byte [200000];

	public CommandeGET(PrintStream ps, String commandeStr) {
		super(ps, commandeStr);
	}

	public void execute()   {
		System.out.println(this.commandeArgs);
		
	}

}
