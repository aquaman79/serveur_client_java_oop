package client;

import java.io.BufferedInputStream;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Main {
  static public String pathClient;

  public static void main(String[] args) {
    System.out.println("Le client FTP");
    String host = "localhost";

    // Liste des commandes possibles
    ArrayList<String> commandes = new ArrayList<String>();
    commandes.add("user");
    commandes.add("pass");
    commandes.add("pwd");
    commandes.add("cd");
    commandes.add("get");
    commandes.add("ls");
    commandes.add("stor");
    commandes.add("bye");

    Pattern pattern = Pattern.compile("(.*[:*?\"<>|].*)");
    Matcher matcher = null;

    // Connexion au serveur
    Socket socket = null;
    PrintWriter pw = null;
    Scanner scan = null;
    BufferedReader br = null;
    try {
      socket = new Socket(host, 2121);

      String envoi = "";
      String name = "";
      pw = new PrintWriter(socket.getOutputStream());
      scan = new Scanner(System.in);
      br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
      boolean commandeValide = true;
      String destination = pathClient;

      // Boucle d'envoi des commandes
      while (!envoi.equals("bye")) {
        // R�ponse du serveur
        String recu = "";
        boolean arreter = false;
        while (!arreter && commandeValide) {
          recu = br.readLine();
          System.out.println(recu);

          String[] val = recu.split("\\s+");
          if (!val[0].equals("1")) {
            arreter = true;
          }

          String[] e = envoi.split("\\s+");
          if (e[0].equals("user") && val[0].equals("0")) {
            // Initialisation du chemin client
            File file = new File(".");
            pathClient = file.getAbsoluteFile().toString();
            pathClient = pathClient.substring(0, pathClient.length() - 1);
            pathClient += "/" + name + "/";
            commandes.remove("user");
          } else if (e[0].equals("pass") && val[0].equals("0")) {
            commandes.remove("pass");
          }
        }

        System.out.println("\nEntrez votre commande :");
        envoi = scan.nextLine();

        String[] tab = envoi.split("\\s+");
        boolean existe = false;
        int i = 0;
        while (!existe && i < commandes.size()) {
          if (commandes.get(i).equals(tab[0])) {
            existe = true;
          }
          i++;
        }

        if (tab.length > 1) {
          matcher = pattern.matcher(tab[1]);
          if (matcher.find()) {
            existe = false;
          }
        }
        if (tab[0].equals("user") && tab.length > 1) {
          name = tab[1];
        }

        if (existe) {
          pw.println(envoi);
          pw.flush();
          commandeValide = true;
        } else {
          commandeValide = false;
          System.out.println("Commande " + tab[0] + " inexistante ou param�tre invalide");
        }
      }

      System.out.println("Au revoir !");

      // Fermeture des flux et de la socket
      br.close();
      scan.close();
      pw.close();
      socket.close();
    } catch (IOException e1) {
      // Fermeture subite du serveur
      System.out.println("Le serveur a ferme. Vous allez etre deconnecte. Au revoir !");
      e1.printStackTrace();

      // Fermeture des flux et de la socket
      try {
        br.close();
        scan.close();
        pw.close();
        socket.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}